import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import Navbar from './components/Navbar';
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import Register from './pages/Register';
import SOPManagement from './pages/SOPManagement';
import SOPDetail from './pages/SOPDetail';
import AssignmentManagement from './pages/AssignmentManagement';
import { GamificationProvider } from './components/GamificationContext';

// Create a custom theme with KEYD Solutions branding
const theme = createTheme({
  palette: {
    primary: {
      main: '#003A5D', // KEYD Solutions blue
    },
    secondary: {
      main: '#FF9800', // Orange for accents
    },
    background: {
      default: '#f5f7fa',
    },
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    h4: {
      fontWeight: 600,
    },
    h5: {
      fontWeight: 600,
    },
    h6: {
      fontWeight: 600,
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          textTransform: 'none',
          fontWeight: 600,
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 12,
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          borderRadius: 12,
        },
      },
    },
  },
});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <GamificationProvider>
        <Router>
          <Navbar />
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/sops" element={<SOPManagement />} />
            <Route path="/sops/:id" element={<SOPDetail />} />
            <Route path="/assignments" element={<AssignmentManagement />} />
            <Route path="/my-tasks" element={<AssignmentManagement />} />
          </Routes>
        </Router>
      </GamificationProvider>
    </ThemeProvider>
  );
}

export default App;
