import React from 'react';
import { 
  Box, 
  Typography, 
  Paper, 
  List, 
  ListItem, 
  ListItemIcon, 
  ListItemText, 
  Checkbox, 
  Button,
  LinearProgress,
  Chip,
  Divider,
  Alert,
  Snackbar
} from '@mui/material';
import { useGamification } from '../components/GamificationContext';
import { PointsAward, BadgeAward } from '../components/GamificationNotifications';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';

interface ChecklistItemProps {
  id: string;
  text: string;
  isCompleted: boolean;
  onToggle: (id: string, completed: boolean) => void;
}

const ChecklistItem: React.FC<ChecklistItemProps> = ({ id, text, isCompleted, onToggle }) => {
  return (
    <ListItem 
      sx={{ 
        py: 1, 
        px: 2, 
        borderRadius: 1,
        mb: 1,
        backgroundColor: isCompleted ? '#f0f7ff' : 'white',
        border: '1px solid',
        borderColor: isCompleted ? '#bbdefb' : '#e0e0e0',
        transition: 'all 0.2s',
        '&:hover': {
          backgroundColor: isCompleted ? '#e3f2fd' : '#f5f5f5',
          transform: 'translateY(-2px)',
          boxShadow: 1
        }
      }}
    >
      <ListItemIcon>
        <Checkbox
          edge="start"
          checked={isCompleted}
          onChange={(e) => onToggle(id, e.target.checked)}
          sx={{
            color: '#003A5D',
            '&.Mui-checked': {
              color: '#003A5D',
            },
          }}
        />
      </ListItemIcon>
      <ListItemText 
        primary={text} 
        sx={{ 
          textDecoration: isCompleted ? 'line-through' : 'none',
          color: isCompleted ? 'text.secondary' : 'text.primary'
        }} 
      />
      {isCompleted && (
        <CheckCircleIcon color="success" sx={{ ml: 1 }} />
      )}
    </ListItem>
  );
};

interface EnhancedSOPDetailProps {
  sop: any;
  onComplete: () => void;
}

const EnhancedSOPDetail: React.FC<EnhancedSOPDetailProps> = ({ sop, onComplete }) => {
  const [checklist, setChecklist] = React.useState<any[]>([]);
  const [showPointsNotification, setShowPointsNotification] = React.useState(false);
  const [showBadgeNotification, setShowBadgeNotification] = React.useState(false);
  const [earnedBadge, setEarnedBadge] = React.useState<any>(null);
  const [completionSnackbar, setCompletionSnackbar] = React.useState(false);
  
  const { addPoints, checkForNewBadges, updateCompletionRate } = useGamification();

  React.useEffect(() => {
    if (sop && sop.checklist) {
      setChecklist(sop.checklist);
    }
  }, [sop]);

  const handleToggleItem = async (id: string, completed: boolean) => {
    const updatedChecklist = checklist.map(item => 
      item.id === id ? { ...item, isCompleted: completed } : item
    );
    
    setChecklist(updatedChecklist);
    
    // Award points for completing an item
    if (completed) {
      await addPoints(10);
      setShowPointsNotification(true);
      setTimeout(() => setShowPointsNotification(false), 3000);
      
      // Check if all items are completed
      const allCompleted = updatedChecklist.every(item => item.isCompleted);
      if (allCompleted) {
        // Award bonus points for completing the entire SOP
        await addPoints(50);
        setCompletionSnackbar(true);
        
        // Check for new badges
        const newBadges = await checkForNewBadges();
        if (newBadges.length > 0) {
          setEarnedBadge(newBadges[0]);
          setShowBadgeNotification(true);
        }
        
        // Update completion rate
        await updateCompletionRate();
        
        // Call the onComplete callback
        onComplete();
      }
    }
  };

  const calculateProgress = () => {
    if (!checklist.length) return 0;
    const completedItems = checklist.filter(item => item.isCompleted).length;
    return (completedItems / checklist.length) * 100;
  };

  const progress = calculateProgress();

  return (
    <Box>
      <Paper sx={{ p: 3, mb: 3, borderRadius: 2, boxShadow: 2 }}>
        <Typography variant="h5" gutterBottom sx={{ color: '#003A5D', fontWeight: 'bold' }}>
          {sop?.title || 'SOP Details'}
        </Typography>
        
        <Typography variant="body1" paragraph>
          {sop?.description || 'No description available.'}
        </Typography>
        
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
          <Box sx={{ flexGrow: 1, mr: 2 }}>
            <LinearProgress 
              variant="determinate" 
              value={progress} 
              sx={{ 
                height: 10, 
                borderRadius: 5,
                backgroundColor: '#e0e0e0',
                '& .MuiLinearProgress-bar': {
                  backgroundColor: progress === 100 ? '#4caf50' : '#003A5D',
                }
              }} 
            />
          </Box>
          <Chip 
            label={`${Math.round(progress)}%`} 
            color={progress === 100 ? "success" : "primary"} 
            sx={{ fontWeight: 'bold' }} 
          />
        </Box>
        
        <Divider sx={{ my: 2 }} />
        
        <Typography variant="h6" gutterBottom sx={{ color: '#003A5D' }}>
          Checklist
        </Typography>
        
        <List sx={{ mt: 2 }}>
          {checklist.length === 0 ? (
            <Typography variant="body2" color="text.secondary">
              No checklist items available.
            </Typography>
          ) : (
            checklist.map((item) => (
              <ChecklistItem
                key={item.id}
                id={item.id}
                text={item.text}
                isCompleted={item.isCompleted}
                onToggle={handleToggleItem}
              />
            ))
          )}
        </List>
        
        {progress === 100 && (
          <Box sx={{ mt: 3, textAlign: 'center' }}>
            <Paper 
              sx={{ 
                p: 2, 
                backgroundColor: '#e8f5e9', 
                borderRadius: 2,
                border: '1px solid #a5d6a7'
              }}
            >
              <CheckCircleIcon color="success" sx={{ fontSize: 40, mb: 1 }} />
              <Typography variant="h6" gutterBottom color="success.main">
                Congratulations!
              </Typography>
              <Typography variant="body1">
                You've completed all items in this SOP.
              </Typography>
            </Paper>
          </Box>
        )}
      </Paper>
      
      {showPointsNotification && (
        <PointsAward points={10} reason="Completed a checklist item" />
      )}
      
      {showBadgeNotification && earnedBadge && (
        <BadgeAward badge={earnedBadge} />
      )}
      
      <Snackbar
        open={completionSnackbar}
        autoHideDuration={6000}
        onClose={() => setCompletionSnackbar(false)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert 
          onClose={() => setCompletionSnackbar(false)} 
          severity="success" 
          sx={{ width: '100%' }}
        >
          SOP completed! You earned 50 bonus points!
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default EnhancedSOPDetail;
