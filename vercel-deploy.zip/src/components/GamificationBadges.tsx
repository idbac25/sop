import React from 'react';
import { 
  Box, 
  Typography, 
  Grid, 
  Paper, 
  Tooltip, 
  Avatar 
} from '@mui/material';
import { useGamification, Badge } from './GamificationContext';
import EmojiEventsIcon from '@mui/icons-material/EmojiEvents';
import WorkspacePremiumIcon from '@mui/icons-material/WorkspacePremium';
import MilitaryTechIcon from '@mui/icons-material/MilitaryTech';
import StarsIcon from '@mui/icons-material/Stars';
import BoltIcon from '@mui/icons-material/Bolt';
import HelpIcon from '@mui/icons-material/Help';

const GamificationBadges: React.FC = () => {
  const { userBadges } = useGamification();

  const getIconForBadge = (iconName: string) => {
    switch (iconName) {
      case 'emoji_events':
        return <EmojiEventsIcon sx={{ fontSize: 40, color: '#FFD700' }} />;
      case 'workspace_premium':
        return <WorkspacePremiumIcon sx={{ fontSize: 40, color: '#C0C0C0' }} />;
      case 'military_tech':
        return <MilitaryTechIcon sx={{ fontSize: 40, color: '#CD7F32' }} />;
      case 'stars':
        return <StarsIcon sx={{ fontSize: 40, color: '#9C27B0' }} />;
      case 'bolt':
        return <BoltIcon sx={{ fontSize: 40, color: '#2196F3' }} />;
      default:
        return <HelpIcon sx={{ fontSize: 40, color: '#757575' }} />;
    }
  };

  const formatDate = (date?: Date) => {
    if (!date) return 'N/A';
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  return (
    <Box>
      <Typography variant="h6" gutterBottom sx={{ color: '#003A5D' }}>
        My Achievements
      </Typography>
      
      {userBadges.length === 0 ? (
        <Paper sx={{ p: 3, textAlign: 'center' }}>
          <Typography variant="body1" color="text.secondary">
            You haven't earned any badges yet. Complete tasks to earn achievements!
          </Typography>
        </Paper>
      ) : (
        <Grid container spacing={2}>
          {userBadges.map((badge) => (
            <Grid item xs={6} sm={4} md={3} key={badge.id}>
              <Tooltip title={`${badge.description} • Earned on ${formatDate(badge.dateEarned)}`}>
                <Paper 
                  sx={{ 
                    p: 2, 
                    display: 'flex', 
                    flexDirection: 'column', 
                    alignItems: 'center',
                    height: '100%',
                    transition: 'transform 0.2s',
                    '&:hover': {
                      transform: 'scale(1.05)',
                      boxShadow: 3
                    }
                  }}
                >
                  <Avatar 
                    sx={{ 
                      width: 60, 
                      height: 60, 
                      mb: 1,
                      bgcolor: '#f0f7ff'
                    }}
                  >
                    {getIconForBadge(badge.icon)}
                  </Avatar>
                  <Typography variant="subtitle1" align="center" sx={{ fontWeight: 'bold' }}>
                    {badge.name}
                  </Typography>
                  <Typography variant="body2" align="center" color="text.secondary">
                    {formatDate(badge.dateEarned)}
                  </Typography>
                </Paper>
              </Tooltip>
            </Grid>
          ))}
        </Grid>
      )}
    </Box>
  );
};

export default GamificationBadges;
