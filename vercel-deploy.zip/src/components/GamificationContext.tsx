import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { auth, db } from '../firebase/config';
import { doc, getDoc, setDoc, updateDoc, increment, collection, query, where, getDocs, orderBy, limit } from 'firebase/firestore';

interface GamificationContextProps {
  userPoints: number;
  userBadges: Badge[];
  leaderboard: LeaderboardUser[];
  completionRate: number;
  addPoints: (points: number) => Promise<void>;
  checkForNewBadges: () => Promise<Badge[]>;
  refreshLeaderboard: () => Promise<void>;
  updateCompletionRate: () => Promise<void>;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  dateEarned?: Date;
}

export interface LeaderboardUser {
  id: string;
  displayName: string;
  points: number;
  rank: number;
}

const GamificationContext = createContext<GamificationContextProps | undefined>(undefined);

export const useGamification = () => {
  const context = useContext(GamificationContext);
  if (!context) {
    throw new Error('useGamification must be used within a GamificationProvider');
  }
  return context;
};

interface GamificationProviderProps {
  children: ReactNode;
}

export const GamificationProvider: React.FC<GamificationProviderProps> = ({ children }) => {
  const [userPoints, setUserPoints] = useState<number>(0);
  const [userBadges, setUserBadges] = useState<Badge[]>([]);
  const [leaderboard, setLeaderboard] = useState<LeaderboardUser[]>([]);
  const [completionRate, setCompletionRate] = useState<number>(0);
  const [companyId, setCompanyId] = useState<string>('');

  // Available badges
  const availableBadges: Badge[] = [
    {
      id: 'first_completion',
      name: 'First Steps',
      description: 'Complete your first SOP checklist',
      icon: 'emoji_events'
    },
    {
      id: 'five_completions',
      name: 'Getting Started',
      description: 'Complete 5 SOP checklists',
      icon: 'workspace_premium'
    },
    {
      id: 'ten_completions',
      name: 'SOP Expert',
      description: 'Complete 10 SOP checklists',
      icon: 'military_tech'
    },
    {
      id: 'perfect_week',
      name: 'Perfect Week',
      description: 'Complete all assigned SOPs for a week',
      icon: 'stars'
    },
    {
      id: 'speed_demon',
      name: 'Speed Demon',
      description: 'Complete an SOP in record time',
      icon: 'bolt'
    }
  ];

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (user) => {
      if (user) {
        try {
          // Get user data including company ID
          const userDoc = await getDoc(doc(db, 'users', user.uid));
          if (userDoc.exists()) {
            const userData = userDoc.data();
            setCompanyId(userData.companyId);
            
            // Initialize gamification data if it doesn't exist
            const gamificationRef = doc(db, 'gamification', user.uid);
            const gamificationDoc = await getDoc(gamificationRef);
            
            if (!gamificationDoc.exists()) {
              await setDoc(gamificationRef, {
                points: 0,
                badges: [],
                completedTasks: 0,
                userId: user.uid,
                companyId: userData.companyId,
                displayName: userData.displayName
              });
              setUserPoints(0);
              setUserBadges([]);
            } else {
              const gamificationData = gamificationDoc.data();
              setUserPoints(gamificationData.points || 0);
              
              // Map badge IDs to full badge objects
              const badges = (gamificationData.badges || []).map((badgeData: any) => {
                const badge = availableBadges.find(b => b.id === badgeData.id) || {
                  id: badgeData.id,
                  name: 'Unknown Badge',
                  description: 'Badge details not available',
                  icon: 'help'
                };
                
                return {
                  ...badge,
                  dateEarned: badgeData.dateEarned ? badgeData.dateEarned.toDate() : new Date()
                };
              });
              
              setUserBadges(badges);
            }
            
            // Load initial leaderboard and completion rate
            await refreshLeaderboard();
            await updateCompletionRate();
          }
        } catch (error) {
          console.error('Error initializing gamification data:', error);
        }
      }
    });
    
    return () => unsubscribe();
  }, []);

  const addPoints = async (points: number) => {
    if (!auth.currentUser) return;
    
    try {
      const gamificationRef = doc(db, 'gamification', auth.currentUser.uid);
      await updateDoc(gamificationRef, {
        points: increment(points)
      });
      
      setUserPoints(prev => prev + points);
      
      // Check for new badges after adding points
      await checkForNewBadges();
      
    } catch (error) {
      console.error('Error adding points:', error);
    }
  };

  const checkForNewBadges = async (): Promise<Badge[]> => {
    if (!auth.currentUser) return [];
    
    try {
      // Get user's completed tasks count
      const gamificationRef = doc(db, 'gamification', auth.currentUser.uid);
      const gamificationDoc = await getDoc(gamificationRef);
      
      if (!gamificationDoc.exists()) return [];
      
      const gamificationData = gamificationDoc.data();
      const completedTasks = gamificationData.completedTasks || 0;
      
      // Check which badges should be awarded
      const newBadges: Badge[] = [];
      
      // First completion badge
      if (completedTasks >= 1 && !userBadges.some(b => b.id === 'first_completion')) {
        const badge = availableBadges.find(b => b.id === 'first_completion')!;
        newBadges.push(badge);
      }
      
      // Five completions badge
      if (completedTasks >= 5 && !userBadges.some(b => b.id === 'five_completions')) {
        const badge = availableBadges.find(b => b.id === 'five_completions')!;
        newBadges.push(badge);
      }
      
      // Ten completions badge
      if (completedTasks >= 10 && !userBadges.some(b => b.id === 'ten_completions')) {
        const badge = availableBadges.find(b => b.id === 'ten_completions')!;
        newBadges.push(badge);
      }
      
      // If new badges were earned, update the database and state
      if (newBadges.length > 0) {
        const badgesToSave = newBadges.map(badge => ({
          id: badge.id,
          dateEarned: new Date()
        }));
        
        const updatedBadges = [...gamificationData.badges || [], ...badgesToSave];
        
        await updateDoc(gamificationRef, {
          badges: updatedBadges
        });
        
        // Update local state with new badges
        setUserBadges(prev => [
          ...prev,
          ...newBadges.map(badge => ({
            ...badge,
            dateEarned: new Date()
          }))
        ]);
      }
      
      return newBadges;
      
    } catch (error) {
      console.error('Error checking for new badges:', error);
      return [];
    }
  };

  const refreshLeaderboard = async () => {
    if (!companyId) return;
    
    try {
      const leaderboardQuery = query(
        collection(db, 'gamification'),
        where('companyId', '==', companyId),
        orderBy('points', 'desc'),
        limit(10)
      );
      
      const leaderboardSnapshot = await getDocs(leaderboardQuery);
      const leaderboardData: LeaderboardUser[] = [];
      
      leaderboardSnapshot.forEach((doc, index) => {
        const data = doc.data();
        leaderboardData.push({
          id: doc.id,
          displayName: data.displayName || 'Unknown User',
          points: data.points || 0,
          rank: index + 1
        });
      });
      
      setLeaderboard(leaderboardData);
      
    } catch (error) {
      console.error('Error refreshing leaderboard:', error);
    }
  };

  const updateCompletionRate = async () => {
    if (!auth.currentUser) return;
    
    try {
      // Get all assignments for the user
      const assignmentsQuery = query(
        collection(db, 'assignments'),
        where('userId', '==', auth.currentUser.uid)
      );
      
      const assignmentsSnapshot = await getDocs(assignmentsQuery);
      
      if (assignmentsSnapshot.empty) {
        setCompletionRate(0);
        return;
      }
      
      let totalAssignments = 0;
      let completedAssignments = 0;
      
      assignmentsSnapshot.forEach(doc => {
        const assignment = doc.data();
        totalAssignments++;
        
        if (assignment.status === 'completed') {
          completedAssignments++;
        }
      });
      
      const rate = totalAssignments > 0 ? (completedAssignments / totalAssignments) * 100 : 0;
      setCompletionRate(rate);
      
    } catch (error) {
      console.error('Error updating completion rate:', error);
    }
  };

  const value = {
    userPoints,
    userBadges,
    leaderboard,
    completionRate,
    addPoints,
    checkForNewBadges,
    refreshLeaderboard,
    updateCompletionRate
  };

  return (
    <GamificationContext.Provider value={value}>
      {children}
    </GamificationContext.Provider>
  );
};

export default GamificationContext;
