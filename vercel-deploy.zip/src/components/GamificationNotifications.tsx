import React from 'react';
import { 
  Box, 
  Typography, 
  Paper, 
  Chip,
  Tooltip,
  Fade
} from '@mui/material';
import { useGamification, Badge } from './GamificationContext';

interface PointsAwardProps {
  points: number;
  reason: string;
}

const PointsAward: React.FC<PointsAwardProps> = ({ points, reason }) => {
  const [visible, setVisible] = React.useState(true);

  React.useEffect(() => {
    const timer = setTimeout(() => {
      setVisible(false);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <Fade in={visible}>
      <Paper 
        elevation={6}
        sx={{
          position: 'fixed',
          bottom: 20,
          right: 20,
          p: 2,
          backgroundColor: '#003A5D',
          color: 'white',
          borderRadius: 2,
          zIndex: 9999,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          minWidth: 200
        }}
      >
        <Typography variant="h6" sx={{ mb: 1 }}>
          +{points} points!
        </Typography>
        <Typography variant="body2">
          {reason}
        </Typography>
      </Paper>
    </Fade>
  );
};

interface BadgeAwardProps {
  badge: Badge;
}

const BadgeAward: React.FC<BadgeAwardProps> = ({ badge }) => {
  const [visible, setVisible] = React.useState(true);

  React.useEffect(() => {
    const timer = setTimeout(() => {
      setVisible(false);
    }, 5000);

    return () => clearTimeout(timer);
  }, []);

  const getIconForBadge = (iconName: string) => {
    switch (iconName) {
      case 'emoji_events':
        return '🏆';
      case 'workspace_premium':
        return '🥈';
      case 'military_tech':
        return '🥉';
      case 'stars':
        return '⭐';
      case 'bolt':
        return '⚡';
      default:
        return '🎖️';
    }
  };

  return (
    <Fade in={visible}>
      <Paper 
        elevation={6}
        sx={{
          position: 'fixed',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          p: 3,
          backgroundColor: '#f8f8f8',
          borderRadius: 2,
          zIndex: 9999,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          minWidth: 300,
          border: '2px solid #003A5D'
        }}
      >
        <Typography variant="h5" sx={{ mb: 2, color: '#003A5D' }}>
          New Achievement Unlocked!
        </Typography>
        
        <Box sx={{ fontSize: 60, mb: 2 }}>
          {getIconForBadge(badge.icon)}
        </Box>
        
        <Typography variant="h6" sx={{ mb: 1 }}>
          {badge.name}
        </Typography>
        
        <Typography variant="body1" sx={{ mb: 2, textAlign: 'center' }}>
          {badge.description}
        </Typography>
        
        <Chip 
          label="Congratulations!" 
          color="primary" 
          sx={{ fontWeight: 'bold' }} 
        />
      </Paper>
    </Fade>
  );
};

export { PointsAward, BadgeAward };
