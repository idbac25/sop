import React from 'react';
import { 
  Box, 
  Typography, 
  Paper, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow,
  Avatar,
  Chip
} from '@mui/material';
import { useGamification } from './GamificationContext';
import EmojiEventsIcon from '@mui/icons-material/EmojiEvents';
import LooksOneIcon from '@mui/icons-material/LooksOne';
import LooksTwoIcon from '@mui/icons-material/LooksTwo';
import Looks3Icon from '@mui/icons-material/Looks3';

const Leaderboard: React.FC = () => {
  const { leaderboard, refreshLeaderboard } = useGamification();

  React.useEffect(() => {
    refreshLeaderboard();
  }, [refreshLeaderboard]);

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <LooksOneIcon sx={{ color: '#FFD700' }} />;
      case 2:
        return <LooksTwoIcon sx={{ color: '#C0C0C0' }} />;
      case 3:
        return <Looks3Icon sx={{ color: '#CD7F32' }} />;
      default:
        return null;
    }
  };

  return (
    <Box>
      <Typography variant="h6" gutterBottom sx={{ color: '#003A5D', display: 'flex', alignItems: 'center' }}>
        <EmojiEventsIcon sx={{ mr: 1 }} /> Top Performers
      </Typography>
      
      <TableContainer component={Paper} sx={{ boxShadow: 2 }}>
        <Table>
          <TableHead sx={{ backgroundColor: '#f5f5f5' }}>
            <TableRow>
              <TableCell align="center" width="15%">Rank</TableCell>
              <TableCell>Employee</TableCell>
              <TableCell align="right">Points</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {leaderboard.length === 0 ? (
              <TableRow>
                <TableCell colSpan={3} align="center">
                  <Typography variant="body2" color="text.secondary" sx={{ py: 2 }}>
                    No data available yet. Complete tasks to appear on the leaderboard!
                  </Typography>
                </TableCell>
              </TableRow>
            ) : (
              leaderboard.map((user) => (
                <TableRow 
                  key={user.id}
                  sx={{ 
                    '&:nth-of-type(odd)': { backgroundColor: '#fafafa' },
                    '&:hover': { backgroundColor: '#f0f7ff' },
                    transition: 'background-color 0.2s'
                  }}
                >
                  <TableCell align="center">
                    {user.rank <= 3 ? (
                      <Avatar 
                        sx={{ 
                          width: 36, 
                          height: 36, 
                          bgcolor: user.rank === 1 ? '#FFF9C4' : user.rank === 2 ? '#F5F5F5' : '#FFCCBC',
                          margin: '0 auto'
                        }}
                      >
                        {getRankIcon(user.rank)}
                      </Avatar>
                    ) : (
                      <Typography variant="body1">{user.rank}</Typography>
                    )}
                  </TableCell>
                  <TableCell>
                    <Typography variant="body1">{user.displayName}</Typography>
                  </TableCell>
                  <TableCell align="right">
                    <Chip 
                      label={`${user.points} pts`} 
                      color={user.rank <= 3 ? "primary" : "default"}
                      size="small"
                      sx={{ 
                        fontWeight: user.rank <= 3 ? 'bold' : 'normal',
                        minWidth: '80px'
                      }}
                    />
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default Leaderboard;
