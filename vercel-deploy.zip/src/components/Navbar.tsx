import React from 'react';
import { AppBar, Toolbar, Typography, Button, Box, Avatar } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { auth } from '../firebase/config';
import { signOut } from 'firebase/auth';
import logo from '../assets/logo.png';

interface NavbarProps {
  isAuthenticated: boolean;
  userRole?: 'company_admin' | 'manager' | 'employee';
}

const Navbar: React.FC<NavbarProps> = ({ isAuthenticated, userRole }) => {
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await signOut(auth);
      navigate('/login');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <AppBar position="static" sx={{ backgroundColor: '#fff', color: '#003A5D' }}>
      <Toolbar>
        <Box 
          component="img" 
          src={logo} 
          alt="KEYD Solutions Logo" 
          sx={{ 
            height: 50, 
            mr: 2,
            cursor: 'pointer'
          }}
          onClick={() => navigate('/')}
        />
        
        <Typography 
          variant="h6" 
          component="div" 
          sx={{ 
            flexGrow: 1,
            fontWeight: 'bold',
            display: { xs: 'none', sm: 'block' }
          }}
        >
          SOP Management Tool
        </Typography>
        
        {isAuthenticated ? (
          <>
            <Box sx={{ display: { xs: 'none', md: 'flex' }, gap: 2 }}>
              <Button color="inherit" onClick={() => navigate('/dashboard')}>
                Dashboard
              </Button>
              
              {(userRole === 'company_admin' || userRole === 'manager') && (
                <>
                  <Button color="inherit" onClick={() => navigate('/sops')}>
                    SOPs
                  </Button>
                  <Button color="inherit" onClick={() => navigate('/assignments')}>
                    Assignments
                  </Button>
                </>
              )}
              
              {userRole === 'company_admin' && (
                <Button color="inherit" onClick={() => navigate('/users')}>
                  Users
                </Button>
              )}
              
              {userRole === 'employee' && (
                <Button color="inherit" onClick={() => navigate('/my-tasks')}>
                  My Tasks
                </Button>
              )}
            </Box>
            
            <Button 
              color="inherit" 
              onClick={handleLogout}
              sx={{ 
                ml: 2,
                backgroundColor: '#003A5D',
                color: 'white',
                '&:hover': {
                  backgroundColor: '#002A40',
                }
              }}
            >
              Logout
            </Button>
          </>
        ) : (
          <Box>
            <Button color="inherit" onClick={() => navigate('/login')}>Login</Button>
            <Button 
              color="inherit" 
              onClick={() => navigate('/register')}
              sx={{ 
                ml: 1,
                backgroundColor: '#003A5D',
                color: 'white',
                '&:hover': {
                  backgroundColor: '#002A40',
                }
              }}
            >
              Register
            </Button>
          </Box>
        )}
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;
