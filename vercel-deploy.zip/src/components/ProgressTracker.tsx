import React from 'react';
import { 
  Box, 
  Typography, 
  LinearProgress, 
  Paper,
  Tooltip,
  CircularProgress
} from '@mui/material';
import { useGamification } from './GamificationContext';

interface ProgressTrackerProps {
  title?: string;
  showPoints?: boolean;
}

const ProgressTracker: React.FC<ProgressTrackerProps> = ({ 
  title = "My Progress", 
  showPoints = true 
}) => {
  const { userPoints, completionRate, updateCompletionRate } = useGamification();

  React.useEffect(() => {
    updateCompletionRate();
  }, [updateCompletionRate]);

  // Determine level based on points
  const calculateLevel = (points: number) => {
    if (points < 100) return 1;
    if (points < 300) return 2;
    if (points < 600) return 3;
    if (points < 1000) return 4;
    return 5;
  };

  const level = calculateLevel(userPoints);
  
  // Calculate progress to next level
  const getProgressToNextLevel = () => {
    if (level === 1) return (userPoints / 100) * 100;
    if (level === 2) return ((userPoints - 100) / 200) * 100;
    if (level === 3) return ((userPoints - 300) / 300) * 100;
    if (level === 4) return ((userPoints - 600) / 400) * 100;
    return 100; // Max level
  };

  const nextLevelProgress = getProgressToNextLevel();
  
  // Points needed for next level
  const getPointsToNextLevel = () => {
    if (level === 1) return 100 - userPoints;
    if (level === 2) return 300 - userPoints;
    if (level === 3) return 600 - userPoints;
    if (level === 4) return 1000 - userPoints;
    return 0; // Max level
  };

  const pointsToNextLevel = getPointsToNextLevel();

  return (
    <Paper sx={{ p: 3, mb: 3 }}>
      <Typography variant="h6" gutterBottom sx={{ color: '#003A5D' }}>
        {title}
      </Typography>
      
      {showPoints && (
        <Box sx={{ mb: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
            <Typography variant="body2" color="text.secondary">
              Level {level}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {pointsToNextLevel > 0 ? `${pointsToNextLevel} points to Level ${level + 1}` : "Max Level"}
            </Typography>
          </Box>
          
          <Tooltip title={`${userPoints} points (${Math.round(nextLevelProgress)}% to next level)`}>
            <LinearProgress 
              variant="determinate" 
              value={nextLevelProgress} 
              sx={{ 
                height: 10, 
                borderRadius: 5,
                backgroundColor: '#e0e0e0',
                '& .MuiLinearProgress-bar': {
                  backgroundColor: '#003A5D',
                }
              }} 
            />
          </Tooltip>
          
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 1 }}>
            <Typography variant="h5" sx={{ fontWeight: 'bold', color: '#003A5D' }}>
              {userPoints} points
            </Typography>
          </Box>
        </Box>
      )}
      
      <Box>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
          <Typography variant="body2" color="text.secondary">
            Task Completion Rate
          </Typography>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <CircularProgress 
              variant="determinate" 
              value={completionRate} 
              size={30}
              thickness={5}
              sx={{
                color: completionRate > 75 ? '#4caf50' : completionRate > 50 ? '#ff9800' : '#f44336',
                mr: 1
              }}
            />
            <Typography variant="body2" color="text.secondary">
              {Math.round(completionRate)}%
            </Typography>
          </Box>
        </Box>
        
        <Tooltip title={`${Math.round(completionRate)}% of assigned tasks completed`}>
          <LinearProgress 
            variant="determinate" 
            value={completionRate} 
            sx={{ 
              height: 10, 
              borderRadius: 5,
              backgroundColor: '#e0e0e0',
              '& .MuiLinearProgress-bar': {
                backgroundColor: completionRate > 75 ? '#4caf50' : completionRate > 50 ? '#ff9800' : '#f44336',
              }
            }} 
          />
        </Tooltip>
      </Box>
    </Paper>
  );
};

export default ProgressTracker;
