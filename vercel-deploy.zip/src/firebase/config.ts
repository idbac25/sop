// Firebase configuration for frontend
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyByNR42GFy9YcCvEdCN9J8uIY2PIm1GtyA",
  authDomain: "pocket-summaries.firebaseapp.com",
  projectId: "pocket-summaries",
  storageBucket: "pocket-summaries.firebasestorage.app",
  messagingSenderId: "605714783793",
  appId: "1:605714783793:web:9a86e2e4aff3693d227f10"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

export { app, auth, db, storage };
