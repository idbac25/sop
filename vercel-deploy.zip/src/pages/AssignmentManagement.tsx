import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Box, 
  Typography, 
  Paper, 
  Grid,
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  ListItemSecondaryAction,
  IconButton,
  Divider,
  CircularProgress,
  Alert,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../firebase/config';
import { onAuthStateChanged } from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  collection, 
  query, 
  where, 
  getDocs, 
  addDoc, 
  serverTimestamp,
  deleteDoc
} from 'firebase/firestore';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import AssignmentIcon from '@mui/icons-material/Assignment';
import PersonIcon from '@mui/icons-material/Person';

const AssignmentManagement: React.FC = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [userRole, setUserRole] = useState<string>('');
  const [companyId, setCompanyId] = useState<string>('');
  const [assignments, setAssignments] = useState<any[]>([]);
  const [sops, setSops] = useState<any[]>([]);
  const [employees, setEmployees] = useState<any[]>([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedSop, setSelectedSop] = useState('');
  const [selectedEmployee, setSelectedEmployee] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [error, setError] = useState('');
  const [dialogLoading, setDialogLoading] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        try {
          // Get user data
          const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
          if (userDoc.exists()) {
            const userData = userDoc.data();
            setUser(userData);
            setUserRole(userData.role);
            setCompanyId(userData.companyId);
            
            // Fetch assignments for the company
            await fetchAssignments(userData.companyId);
            
            // Fetch SOPs for assignment creation
            await fetchSOPs(userData.companyId);
            
            // Fetch employees for assignment creation
            await fetchEmployees(userData.companyId);
          }
        } catch (error) {
          console.error('Error fetching user data:', error);
        } finally {
          setLoading(false);
        }
      } else {
        // No user is signed in
        navigate('/login');
      }
    });

    return () => unsubscribe();
  }, [navigate]);

  const fetchAssignments = async (companyId: string) => {
    try {
      const assignmentsQuery = query(
        collection(db, 'assignments'),
        where('companyId', '==', companyId)
      );
      const assignmentsSnapshot = await getDocs(assignmentsQuery);
      
      const assignmentsArray: any[] = [];
      assignmentsSnapshot.forEach(doc => {
        assignmentsArray.push({ id: doc.id, ...doc.data() });
      });
      
      // Sort by assigned date (newest first)
      assignmentsArray.sort((a, b) => {
        const dateA = a.assignedAt?.toDate() || new Date(0);
        const dateB = b.assignedAt?.toDate() || new Date(0);
        return dateB.getTime() - dateA.getTime();
      });
      
      setAssignments(assignmentsArray);
    } catch (error) {
      console.error('Error fetching assignments:', error);
    }
  };

  const fetchSOPs = async (companyId: string) => {
    try {
      const sopsQuery = query(
        collection(db, 'sops'),
        where('companyId', '==', companyId)
      );
      const sopsSnapshot = await getDocs(sopsQuery);
      
      const sopsArray: any[] = [];
      sopsSnapshot.forEach(doc => {
        sopsArray.push({ id: doc.id, ...doc.data() });
      });
      
      setSops(sopsArray);
    } catch (error) {
      console.error('Error fetching SOPs:', error);
    }
  };

  const fetchEmployees = async (companyId: string) => {
    try {
      const employeesQuery = query(
        collection(db, 'users'),
        where('companyId', '==', companyId),
        where('role', '==', 'employee')
      );
      const employeesSnapshot = await getDocs(employeesQuery);
      
      const employeesArray: any[] = [];
      employeesSnapshot.forEach(doc => {
        employeesArray.push({ id: doc.id, ...doc.data() });
      });
      
      setEmployees(employeesArray);
    } catch (error) {
      console.error('Error fetching employees:', error);
    }
  };

  const handleOpenDialog = () => {
    setSelectedSop('');
    setSelectedEmployee('');
    setDueDate('');
    setError('');
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleCreateAssignment = async () => {
    if (!selectedSop) {
      setError('Please select an SOP');
      return;
    }
    
    if (!selectedEmployee) {
      setError('Please select an employee');
      return;
    }
    
    if (!dueDate) {
      setError('Please set a due date');
      return;
    }
    
    setDialogLoading(true);
    setError('');
    
    try {
      // Get SOP details
      const sopDoc = await getDoc(doc(db, 'sops', selectedSop));
      if (!sopDoc.exists()) {
        throw new Error('Selected SOP not found');
      }
      const sopData = sopDoc.data();
      
      // Add new assignment document
      await addDoc(collection(db, 'assignments'), {
        sopId: selectedSop,
        sopTitle: sopData.title,
        userId: selectedEmployee,
        companyId: companyId,
        assignedBy: user.uid,
        assignedAt: serverTimestamp(),
        dueDate: new Date(dueDate),
        status: 'pending',
        completedAt: null
      });
      
      // Refresh assignments list
      await fetchAssignments(companyId);
      handleCloseDialog();
    } catch (error: any) {
      console.error('Error creating assignment:', error);
      setError(error.message || 'Failed to create assignment. Please try again.');
    } finally {
      setDialogLoading(false);
    }
  };

  const handleDeleteAssignment = async (assignmentId: string) => {
    if (window.confirm('Are you sure you want to delete this assignment? This action cannot be undone.')) {
      try {
        await deleteDoc(doc(db, 'assignments', assignmentId));
        // Refresh assignments list
        await fetchAssignments(companyId);
      } catch (error) {
        console.error('Error deleting assignment:', error);
        alert('Failed to delete assignment. Please try again.');
      }
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  // Only company admins and managers can access this page
  if (userRole !== 'company_admin' && userRole !== 'manager') {
    return (
      <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
        <Alert severity="error">
          You do not have permission to access this page.
        </Alert>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" sx={{ color: '#003A5D', fontWeight: 'bold' }}>
          Assignment Management
        </Typography>
        <Button 
          variant="contained" 
          startIcon={<AddIcon />}
          onClick={handleOpenDialog}
          sx={{ 
            backgroundColor: '#003A5D',
            '&:hover': {
              backgroundColor: '#002A40',
            }
          }}
        >
          Create New Assignment
        </Button>
      </Box>
      
      <Paper sx={{ p: 3 }}>
        {assignments.length === 0 ? (
          <Box sx={{ textAlign: 'center', py: 4 }}>
            <Typography variant="h6" color="text.secondary" gutterBottom>
              No Assignments Found
            </Typography>
            <Typography variant="body1" color="text.secondary">
              Assign SOPs to employees to track their progress.
            </Typography>
            <Button 
              variant="contained" 
              startIcon={<AddIcon />}
              onClick={handleOpenDialog}
              sx={{ 
                mt: 2,
                backgroundColor: '#003A5D',
                '&:hover': {
                  backgroundColor: '#002A40',
                }
              }}
            >
              Create New Assignment
            </Button>
          </Box>
        ) : (
          <List>
            {assignments.map((assignment) => (
              <React.Fragment key={assignment.id}>
                <ListItem 
                  sx={{ 
                    py: 2,
                    '&:hover': {
                      backgroundColor: 'rgba(0, 0, 0, 0.04)',
                    }
                  }}
                >
                  <ListItemIcon>
                    <AssignmentIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText 
                    primary={
                      <Typography variant="h6" sx={{ fontSize: '1.1rem' }}>
                        {assignment.sopTitle || 'SOP Assignment'}
                      </Typography>
                    } 
                    secondary={
                      <>
                        <Box sx={{ display: 'flex', alignItems: 'center', mt: 0.5 }}>
                          <PersonIcon sx={{ fontSize: '0.9rem', mr: 0.5, color: 'text.secondary' }} />
                          <Typography variant="body2" color="text.secondary">
                            Assigned to: {assignment.userName || 'Employee'}
                          </Typography>
                        </Box>
                        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
                          Due: {assignment.dueDate?.toDate().toLocaleDateString() || 'N/A'}
                        </Typography>
                        <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                          Assigned: {assignment.assignedAt?.toDate().toLocaleDateString() || 'N/A'}
                        </Typography>
                      </>
                    } 
                  />
                  <Chip 
                    label={assignment.status} 
                    color={
                      assignment.status === 'completed' 
                        ? 'success' 
                        : assignment.status === 'in_progress' 
                          ? 'primary' 
                          : 'warning'
                    } 
                    size="small" 
                    sx={{ mr: 2 }}
                  />
                  <ListItemSecondaryAction>
                    <IconButton 
                      edge="end" 
                      aria-label="view"
                      onClick={() => navigate(`/assignments/${assignment.id}`)}
                      sx={{ mr: 1 }}
                    >
                      <EditIcon />
                    </IconButton>
                    <IconButton 
                      edge="end" 
                      aria-label="delete"
                      onClick={() => handleDeleteAssignment(assignment.id)}
                    >
                      <DeleteIcon />
                    </IconButton>
                  </ListItemSecondaryAction>
                </ListItem>
                <Divider />
              </React.Fragment>
            ))}
          </List>
        )}
      </Paper>
      
      {/* Create Assignment Dialog */}
      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ color: '#003A5D', fontWeight: 'bold' }}>
          Create New Assignment
        </DialogTitle>
        <DialogContent>
          {error && (
            <Alert severity="error" sx={{ mb: 2 }}>
              {error}
            </Alert>
          )}
          
          <FormControl fullWidth sx={{ mb: 2, mt: 1 }}>
            <InputLabel id="sop-select-label">Select SOP</InputLabel>
            <Select
              labelId="sop-select-label"
              id="sop-select"
              value={selectedSop}
              label="Select SOP"
              onChange={(e) => setSelectedSop(e.target.value)}
            >
              {sops.map((sop) => (
                <MenuItem key={sop.id} value={sop.id}>
                  {sop.title}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          
          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel id="employee-select-label">Select Employee</InputLabel>
            <Select
              labelId="employee-select-label"
              id="employee-select"
              value={selectedEmployee}
              label="Select Employee"
              onChange={(e) => setSelectedEmployee(e.target.value)}
            >
              {employees.map((employee) => (
                <MenuItem key={employee.id} value={employee.id}>
                  {employee.displayName} ({employee.email})
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          
          <TextField
            margin="dense"
            id="dueDate"
            label="Due Date"
            type="date"
            fullWidth
            variant="outlined"
            InputLabelProps={{
              shrink: true,
            }}
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
          />
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button 
            onClick={handleCreateAssignment} 
            variant="contained"
            disabled={dialogLoading}
            sx={{ 
              backgroundColor: '#003A5D',
              '&:hover': {
                backgroundColor: '#002A40',
              }
            }}
          >
            {dialogLoading ? <CircularProgress size={24} /> : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default AssignmentManagement;
