import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Box, 
  Typography, 
  Paper, 
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  CircularProgress,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip,
  Tab,
  Tabs
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../firebase/config';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc, collection, query, where, getDocs } from 'firebase/firestore';
import AssignmentIcon from '@mui/icons-material/Assignment';
import PeopleIcon from '@mui/icons-material/People';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import PendingIcon from '@mui/icons-material/Pending';
import EmojiEventsIcon from '@mui/icons-material/EmojiEvents';
import { GamificationProvider, useGamification } from '../components/GamificationContext';
import ProgressTracker from '../components/ProgressTracker';
import GamificationBadges from '../components/GamificationBadges';
import Leaderboard from '../components/Leaderboard';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`dashboard-tabpanel-${index}`}
      aria-labelledby={`dashboard-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ py: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

const DashboardContent: React.FC = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [userRole, setUserRole] = useState<string>('');
  const [company, setCompany] = useState<any>(null);
  const [stats, setStats] = useState({
    totalSops: 0,
    totalEmployees: 0,
    completedTasks: 0,
    pendingTasks: 0
  });
  const [recentSops, setRecentSops] = useState<any[]>([]);
  const [recentAssignments, setRecentAssignments] = useState<any[]>([]);
  const [tabValue, setTabValue] = useState(0);
  const { userPoints } = useGamification();

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        try {
          // Get user data
          const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
          if (userDoc.exists()) {
            const userData = userDoc.data();
            setUser(userData);
            setUserRole(userData.role);
            
            // Get company data
            const companyDoc = await getDoc(doc(db, 'companies', userData.companyId));
            if (companyDoc.exists()) {
              setCompany(companyDoc.data());
            }
            
            // Get stats based on role
            if (userData.role === 'company_admin' || userData.role === 'manager') {
              // Get SOPs count
              const sopsQuery = query(
                collection(db, 'sops'),
                where('companyId', '==', userData.companyId)
              );
              const sopsSnapshot = await getDocs(sopsQuery);
              
              // Get employees count
              const employeesQuery = query(
                collection(db, 'users'),
                where('companyId', '==', userData.companyId)
              );
              const employeesSnapshot = await getDocs(employeesQuery);
              
              // Get assignments stats
              const assignmentsQuery = query(
                collection(db, 'assignments'),
                where('companyId', '==', userData.companyId)
              );
              const assignmentsSnapshot = await getDocs(assignmentsQuery);
              
              let completed = 0;
              let pending = 0;
              assignmentsSnapshot.forEach(doc => {
                const assignment = doc.data();
                if (assignment.status === 'completed') {
                  completed++;
                } else {
                  pending++;
                }
              });
              
              setStats({
                totalSops: sopsSnapshot.size,
                totalEmployees: employeesSnapshot.size,
                completedTasks: completed,
                pendingTasks: pending
              });
              
              // Get recent SOPs
              const recentSopsArray: any[] = [];
              sopsSnapshot.forEach(doc => {
                recentSopsArray.push({ id: doc.id, ...doc.data() });
              });
              recentSopsArray.sort((a, b) => b.createdAt - a.createdAt);
              setRecentSops(recentSopsArray.slice(0, 5));
              
              // Get recent assignments
              const recentAssignmentsArray: any[] = [];
              assignmentsSnapshot.forEach(doc => {
                recentAssignmentsArray.push({ id: doc.id, ...doc.data() });
              });
              recentAssignmentsArray.sort((a, b) => b.assignedAt - a.assignedAt);
              setRecentAssignments(recentAssignmentsArray.slice(0, 5));
            } else {
              // Employee role - get their assignments
              const assignmentsQuery = query(
                collection(db, 'assignments'),
                where('userId', '==', currentUser.uid)
              );
              const assignmentsSnapshot = await getDocs(assignmentsQuery);
              
              let completed = 0;
              let pending = 0;
              const recentAssignmentsArray: any[] = [];
              
              assignmentsSnapshot.forEach(doc => {
                const assignment = doc.data();
                recentAssignmentsArray.push({ id: doc.id, ...assignment });
                
                if (assignment.status === 'completed') {
                  completed++;
                } else {
                  pending++;
                }
              });
              
              setStats({
                totalSops: 0,
                totalEmployees: 0,
                completedTasks: completed,
                pendingTasks: pending
              });
              
              recentAssignmentsArray.sort((a, b) => b.assignedAt - a.assignedAt);
              setRecentAssignments(recentAssignmentsArray.slice(0, 5));
            }
          }
        } catch (error) {
          console.error('Error fetching user data:', error);
        } finally {
          setLoading(false);
        }
      } else {
        // No user is signed in
        navigate('/login');
      }
    });

    return () => unsubscribe();
  }, [navigate]);

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Paper sx={{ p: 3, mb: 4, borderRadius: 2, boxShadow: 3 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Box>
            <Typography variant="h4" gutterBottom sx={{ color: '#003A5D', fontWeight: 'bold' }}>
              Welcome back, {user?.displayName}!
            </Typography>
            <Typography variant="body1" color="text.secondary">
              {company?.name} • {userRole === 'company_admin' ? 'Administrator' : userRole === 'manager' ? 'Manager' : 'Employee'}
            </Typography>
          </Box>
          <Chip 
            icon={<EmojiEventsIcon />} 
            label={`${userPoints} points`} 
            color="primary" 
            sx={{ 
              fontWeight: 'bold', 
              fontSize: '1rem', 
              py: 2.5, 
              px: 1,
              '& .MuiChip-icon': { fontSize: '1.5rem' }
            }} 
          />
        </Box>
      </Paper>
      
      <ProgressTracker />
      
      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 2 }}>
        <Tabs 
          value={tabValue} 
          onChange={handleTabChange} 
          aria-label="dashboard tabs"
          sx={{
            '& .MuiTab-root': { fontWeight: 'bold' },
            '& .Mui-selected': { color: '#003A5D' },
            '& .MuiTabs-indicator': { backgroundColor: '#003A5D' }
          }}
        >
          <Tab label="Overview" id="dashboard-tab-0" aria-controls="dashboard-tabpanel-0" />
          <Tab label="Achievements" id="dashboard-tab-1" aria-controls="dashboard-tabpanel-1" />
          <Tab label="Leaderboard" id="dashboard-tab-2" aria-controls="dashboard-tabpanel-2" />
        </Tabs>
      </Box>
      
      <TabPanel value={tabValue} index={0}>
        <Grid container spacing={3}>
          {/* Stats Cards */}
          {(userRole === 'company_admin' || userRole === 'manager') && (
            <>
              <Grid item xs={12} sm={6} md={3}>
                <Card sx={{ height: '100%', borderRadius: 2, boxShadow: 2, transition: 'transform 0.2s', '&:hover': { transform: 'translateY(-5px)', boxShadow: 4 } }}>
                  <CardContent>
                    <AssignmentIcon sx={{ fontSize: 40, color: '#003A5D', mb: 1 }} />
                    <Typography variant="h5" component="div">
                      {stats.totalSops}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Total SOPs
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} sm={6} md={3}>
                <Card sx={{ height: '100%', borderRadius: 2, boxShadow: 2, transition: 'transform 0.2s', '&:hover': { transform: 'translateY(-5px)', boxShadow: 4 } }}>
                  <CardContent>
                    <PeopleIcon sx={{ fontSize: 40, color: '#003A5D', mb: 1 }} />
                    <Typography variant="h5" component="div">
                      {stats.totalEmployees}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Total Employees
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            </>
          )}
          
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ height: '100%', borderRadius: 2, boxShadow: 2, transition: 'transform 0.2s', '&:hover': { transform: 'translateY(-5px)', boxShadow: 4 } }}>
              <CardContent>
                <CheckCircleIcon sx={{ fontSize: 40, color: 'green', mb: 1 }} />
                <Typography variant="h5" component="div">
                  {stats.completedTasks}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Completed Tasks
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ height: '100%', borderRadius: 2, boxShadow: 2, transition: 'transform 0.2s', '&:hover': { transform: 'translateY(-5px)', boxShadow: 4 } }}>
              <CardContent>
                <PendingIcon sx={{ fontSize: 40, color: 'orange', mb: 1 }} />
                <Typography variant="h5" component="div">
                  {stats.pendingTasks}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Pending Tasks
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          
          {/* Recent SOPs */}
          {(userRole === 'company_admin' || userRole === 'manager') && recentSops.length > 0 && (
            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 2, height: '100%', borderRadius: 2, boxShadow: 2 }}>
                <Typography variant="h6" gutterBottom sx={{ color: '#003A5D' }}>
                  Recent SOPs
                </Typography>
                <Divider sx={{ mb: 2 }} />
                <List>
                  {recentSops.map((sop) => (
                    <ListItem 
                      key={sop.id} 
                      sx={{ 
                        px: 1, 
                        py: 0.5,
                        borderRadius: 1,
                        '&:hover': { backgroundColor: '#f5f5f5' }
                      }}
                    >
                      <ListItemIcon>
                        <AssignmentIcon color="primary" />
                      </ListItemIcon>
                      <ListItemText 
                        primary={sop.title} 
                        secondary={`Created: ${sop.createdAt?.toDate().toLocaleDateString() || 'N/A'}`} 
                      />
                      <Button 
                        size="small" 
                        variant="outlined" 
                        onClick={() => navigate(`/sops/${sop.id}`)}
                      >
                        View
                      </Button>
                    </ListItem>
                  ))}
                </List>
                <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end' }}>
                  <Button 
                    variant="contained" 
                    onClick={() => navigate('/sops')}
                    sx={{ 
                      backgroundColor: '#003A5D',
                      '&:hover': {
                        backgroundColor: '#002A40',
                      }
                    }}
                  >
                    View All SOPs
                  </Button>
                </Box>
              </Paper>
            </Grid>
          )}
          
          {/* Recent Assignments */}
          {recentAssignments.length > 0 && (
            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 2, height: '100%', borderRadius: 2, boxShadow: 2 }}>
                <Typography variant="h6" gutterBottom sx={{ color: '#003A5D' }}>
                  {userRole === 'employee' ? 'My Tasks' : 'Recent Assignments'}
                </Typography>
                <Divider sx={{ mb: 2 }} />
                <List>
                  {recentAssignments.map((assignment) => (
                    <ListItem 
                      key={assignment.id} 
                      sx={{ 
                        px: 1, 
                        py: 0.5,
                        borderRadius: 1,
                        '&:hover': { backgroundColor: '#f5f5f5' }
                      }}
                    >
                      <ListItemIcon>
                        {assignment.status === 'completed' ? 
                          <CheckCircleIcon color="success" /> : 
                          <PendingIcon color="warning" />
                        }
                      </ListItemIcon>
                      <ListItemText 
                        primary={assignment.sopTitle || 'SOP Task'} 
                        secondary={`Due: ${assignment.dueDate?.toDate().toLocaleDateString() || 'N/A'}`} 
                      />
                      <Chip 
                        label={assignment.status} 
                        color={assignment.status === 'completed' ? 'success' : 'warning'} 
                        size="small" 
                        sx={{ mr: 1 }}
                      />
                      <Button 
                        size="small" 
                        variant="outlined" 
                        onClick={() => navigate(`/assignments/${assignment.id}`)}
                      >
                        View
                      </Button>
                    </ListItem>
                  ))}
                </List>
                <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end' }}>
                  <Button 
                    variant="contained" 
                    onClick={() => navigate(userRole === 'employee' ? '/my-tasks' : '/assignments')}
                    sx={{ 
                      backgroundColor: '#003A5D',
                      '&:hover': {
                        backgroundColor: '#002A40',
                      }
                    }}
                  >
                    View All {userRole === 'employee' ? 'Tasks' : 'Assignments'}
                  </Button>
                </Box>
              </Paper>
            </Grid>
          )}
        </Grid>
      </TabPanel>
      
      <TabPanel value={tabValue} index={1}>
        <GamificationBadges />
      </TabPanel>
      
      <TabPanel value={tabValue} index={2}>
        <Leaderboard />
      </TabPanel>
    </Container>
  );
};

const Dashboard: React.FC = () => {
  return (
    <GamificationProvider>
      <DashboardContent />
    </GamificationProvider>
  );
};

export default Dashboard;
