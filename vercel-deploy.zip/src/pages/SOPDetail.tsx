import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Box, 
  Typography, 
  Paper, 
  Grid,
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Divider,
  CircularProgress,
  Alert,
  Checkbox,
  FormControlLabel,
  Card,
  CardContent
} from '@mui/material';
import { useNavigate, useParams } from 'react-router-dom';
import { auth, db } from '../firebase/config';
import { onAuthStateChanged } from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  collection, 
  query, 
  where, 
  getDocs, 
  addDoc, 
  updateDoc,
  serverTimestamp,
  orderBy
} from 'firebase/firestore';
import AddIcon from '@mui/icons-material/Add';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import RadioButtonUncheckedIcon from '@mui/icons-material/RadioButtonUnchecked';

const SOPDetail: React.FC = () => {
  const { sopId } = useParams<{ sopId: string }>();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [userRole, setUserRole] = useState<string>('');
  const [sop, setSop] = useState<any>(null);
  const [steps, setSteps] = useState<any[]>([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [stepTitle, setStepTitle] = useState('');
  const [stepDescription, setStepDescription] = useState('');
  const [isRequired, setIsRequired] = useState(true);
  const [error, setError] = useState('');
  const [dialogLoading, setDialogLoading] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        try {
          // Get user data
          const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
          if (userDoc.exists()) {
            const userData = userDoc.data();
            setUser(userData);
            setUserRole(userData.role);
            
            // Fetch SOP details
            if (sopId) {
              await fetchSOPDetails(sopId);
              await fetchSOPSteps(sopId);
            }
          }
        } catch (error) {
          console.error('Error fetching user data:', error);
        } finally {
          setLoading(false);
        }
      } else {
        // No user is signed in
        navigate('/login');
      }
    });

    return () => unsubscribe();
  }, [navigate, sopId]);

  const fetchSOPDetails = async (id: string) => {
    try {
      const sopDoc = await getDoc(doc(db, 'sops', id));
      if (sopDoc.exists()) {
        setSop({ id: sopDoc.id, ...sopDoc.data() });
      } else {
        navigate('/sops');
      }
    } catch (error) {
      console.error('Error fetching SOP details:', error);
    }
  };

  const fetchSOPSteps = async (id: string) => {
    try {
      const stepsQuery = query(
        collection(db, `sops/${id}/steps`),
        orderBy('order', 'asc')
      );
      const stepsSnapshot = await getDocs(stepsQuery);
      
      const stepsArray: any[] = [];
      stepsSnapshot.forEach(doc => {
        stepsArray.push({ id: doc.id, ...doc.data() });
      });
      
      setSteps(stepsArray);
    } catch (error) {
      console.error('Error fetching SOP steps:', error);
    }
  };

  const handleOpenDialog = () => {
    setStepTitle('');
    setStepDescription('');
    setIsRequired(true);
    setError('');
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleAddStep = async () => {
    if (!stepTitle.trim()) {
      setError('Step title is required');
      return;
    }
    
    setDialogLoading(true);
    setError('');
    
    try {
      if (!sopId) return;
      
      // Add new step document
      await addDoc(collection(db, `sops/${sopId}/steps`), {
        title: stepTitle,
        description: stepDescription,
        order: steps.length + 1,
        isRequired: isRequired
      });
      
      // Update SOP's updatedAt timestamp
      await updateDoc(doc(db, 'sops', sopId), {
        updatedAt: serverTimestamp()
      });
      
      // Refresh steps list
      await fetchSOPSteps(sopId);
      handleCloseDialog();
    } catch (error: any) {
      console.error('Error adding step:', error);
      setError(error.message || 'Failed to add step. Please try again.');
    } finally {
      setDialogLoading(false);
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  // Only company admins and managers can edit SOPs
  const canEdit = userRole === 'company_admin' || userRole === 'manager';

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box>
          <Button 
            variant="outlined" 
            onClick={() => navigate('/sops')}
            sx={{ mb: 1 }}
          >
            Back to SOPs
          </Button>
          <Typography variant="h4" sx={{ color: '#003A5D', fontWeight: 'bold' }}>
            {sop?.title || 'SOP Details'}
          </Typography>
          <Typography variant="body1" color="text.secondary">
            {sop?.description || 'No description provided'}
          </Typography>
        </Box>
        
        {canEdit && (
          <Button 
            variant="contained" 
            startIcon={<AddIcon />}
            onClick={handleOpenDialog}
            sx={{ 
              backgroundColor: '#003A5D',
              '&:hover': {
                backgroundColor: '#002A40',
              }
            }}
          >
            Add Step
          </Button>
        )}
      </Box>
      
      <Paper sx={{ p: 3, mb: 4 }}>
        <Typography variant="h6" gutterBottom sx={{ color: '#003A5D' }}>
          SOP Checklist
        </Typography>
        
        {steps.length === 0 ? (
          <Box sx={{ textAlign: 'center', py: 4 }}>
            <Typography variant="body1" color="text.secondary">
              No steps have been added to this SOP yet.
            </Typography>
            {canEdit && (
              <Button 
                variant="contained" 
                startIcon={<AddIcon />}
                onClick={handleOpenDialog}
                sx={{ 
                  mt: 2,
                  backgroundColor: '#003A5D',
                  '&:hover': {
                    backgroundColor: '#002A40',
                  }
                }}
              >
                Add First Step
              </Button>
            )}
          </Box>
        ) : (
          <List>
            {steps.map((step, index) => (
              <React.Fragment key={step.id}>
                <ListItem 
                  sx={{ 
                    py: 2,
                    '&:hover': {
                      backgroundColor: 'rgba(0, 0, 0, 0.04)',
                    }
                  }}
                >
                  <ListItemIcon>
                    <Typography variant="h6" sx={{ fontWeight: 'bold', color: '#003A5D' }}>
                      {index + 1}
                    </Typography>
                  </ListItemIcon>
                  <ListItemText 
                    primary={
                      <Typography variant="h6" sx={{ fontSize: '1.1rem' }}>
                        {step.title}
                        {step.isRequired && (
                          <Typography component="span" color="error" sx={{ ml: 1, fontSize: '0.8rem' }}>
                            (Required)
                          </Typography>
                        )}
                      </Typography>
                    } 
                    secondary={step.description || 'No description provided'} 
                  />
                </ListItem>
                <Divider />
              </React.Fragment>
            ))}
          </List>
        )}
      </Paper>
      
      {canEdit && (
        <Paper sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom sx={{ color: '#003A5D' }}>
            Assign this SOP
          </Typography>
          <Button 
            variant="contained" 
            onClick={() => navigate(`/assignments/new?sopId=${sopId}`)}
            sx={{ 
              mt: 1,
              backgroundColor: '#003A5D',
              '&:hover': {
                backgroundColor: '#002A40',
              }
            }}
          >
            Create Assignment
          </Button>
        </Paper>
      )}
      
      {/* Add Step Dialog */}
      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ color: '#003A5D', fontWeight: 'bold' }}>
          Add SOP Step
        </DialogTitle>
        <DialogContent>
          {error && (
            <Alert severity="error" sx={{ mb: 2 }}>
              {error}
            </Alert>
          )}
          <TextField
            autoFocus
            margin="dense"
            id="title"
            label="Step Title"
            type="text"
            fullWidth
            variant="outlined"
            value={stepTitle}
            onChange={(e) => setStepTitle(e.target.value)}
            sx={{ mb: 2 }}
          />
          <TextField
            margin="dense"
            id="description"
            label="Description"
            type="text"
            fullWidth
            variant="outlined"
            multiline
            rows={4}
            value={stepDescription}
            onChange={(e) => setStepDescription(e.target.value)}
            sx={{ mb: 2 }}
          />
          <FormControlLabel
            control={
              <Checkbox 
                checked={isRequired} 
                onChange={(e) => setIsRequired(e.target.checked)} 
              />
            }
            label="This step is required"
          />
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button 
            onClick={handleAddStep} 
            variant="contained"
            disabled={dialogLoading}
            sx={{ 
              backgroundColor: '#003A5D',
              '&:hover': {
                backgroundColor: '#002A40',
              }
            }}
          >
            {dialogLoading ? <CircularProgress size={24} /> : 'Add Step'}
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default SOPDetail;
