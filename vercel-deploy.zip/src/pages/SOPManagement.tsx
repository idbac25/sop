import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Box, 
  Typography, 
  Paper, 
  Grid,
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  ListItemSecondaryAction,
  IconButton,
  Divider,
  CircularProgress,
  Alert
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../firebase/config';
import { onAuthStateChanged } from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  collection, 
  query, 
  where, 
  getDocs, 
  addDoc, 
  serverTimestamp,
  deleteDoc
} from 'firebase/firestore';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import AssignmentIcon from '@mui/icons-material/Assignment';

const SOPManagement: React.FC = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [userRole, setUserRole] = useState<string>('');
  const [companyId, setCompanyId] = useState<string>('');
  const [sops, setSops] = useState<any[]>([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [sopTitle, setSopTitle] = useState('');
  const [sopDescription, setSopDescription] = useState('');
  const [error, setError] = useState('');
  const [dialogLoading, setDialogLoading] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        try {
          // Get user data
          const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
          if (userDoc.exists()) {
            const userData = userDoc.data();
            setUser(userData);
            setUserRole(userData.role);
            setCompanyId(userData.companyId);
            
            // Fetch SOPs for the company
            await fetchSOPs(userData.companyId);
          }
        } catch (error) {
          console.error('Error fetching user data:', error);
        } finally {
          setLoading(false);
        }
      } else {
        // No user is signed in
        navigate('/login');
      }
    });

    return () => unsubscribe();
  }, [navigate]);

  const fetchSOPs = async (companyId: string) => {
    try {
      const sopsQuery = query(
        collection(db, 'sops'),
        where('companyId', '==', companyId)
      );
      const sopsSnapshot = await getDocs(sopsQuery);
      
      const sopsArray: any[] = [];
      sopsSnapshot.forEach(doc => {
        sopsArray.push({ id: doc.id, ...doc.data() });
      });
      
      // Sort by creation date (newest first)
      sopsArray.sort((a, b) => {
        const dateA = a.createdAt?.toDate() || new Date(0);
        const dateB = b.createdAt?.toDate() || new Date(0);
        return dateB.getTime() - dateA.getTime();
      });
      
      setSops(sopsArray);
    } catch (error) {
      console.error('Error fetching SOPs:', error);
    }
  };

  const handleOpenDialog = () => {
    setSopTitle('');
    setSopDescription('');
    setError('');
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleCreateSOP = async () => {
    if (!sopTitle.trim()) {
      setError('SOP title is required');
      return;
    }
    
    setDialogLoading(true);
    setError('');
    
    try {
      // Add new SOP document
      await addDoc(collection(db, 'sops'), {
        title: sopTitle,
        description: sopDescription,
        companyId: companyId,
        createdBy: user.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        isActive: true
      });
      
      // Refresh SOPs list
      await fetchSOPs(companyId);
      handleCloseDialog();
    } catch (error: any) {
      console.error('Error creating SOP:', error);
      setError(error.message || 'Failed to create SOP. Please try again.');
    } finally {
      setDialogLoading(false);
    }
  };

  const handleDeleteSOP = async (sopId: string) => {
    if (window.confirm('Are you sure you want to delete this SOP? This action cannot be undone.')) {
      try {
        await deleteDoc(doc(db, 'sops', sopId));
        // Refresh SOPs list
        await fetchSOPs(companyId);
      } catch (error) {
        console.error('Error deleting SOP:', error);
        alert('Failed to delete SOP. Please try again.');
      }
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  // Only company admins and managers can access this page
  if (userRole !== 'company_admin' && userRole !== 'manager') {
    return (
      <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
        <Alert severity="error">
          You do not have permission to access this page.
        </Alert>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" sx={{ color: '#003A5D', fontWeight: 'bold' }}>
          SOP Management
        </Typography>
        <Button 
          variant="contained" 
          startIcon={<AddIcon />}
          onClick={handleOpenDialog}
          sx={{ 
            backgroundColor: '#003A5D',
            '&:hover': {
              backgroundColor: '#002A40',
            }
          }}
        >
          Create New SOP
        </Button>
      </Box>
      
      <Paper sx={{ p: 3 }}>
        {sops.length === 0 ? (
          <Box sx={{ textAlign: 'center', py: 4 }}>
            <Typography variant="h6" color="text.secondary" gutterBottom>
              No SOPs Found
            </Typography>
            <Typography variant="body1" color="text.secondary">
              Create your first Standard Operating Procedure to get started.
            </Typography>
            <Button 
              variant="contained" 
              startIcon={<AddIcon />}
              onClick={handleOpenDialog}
              sx={{ 
                mt: 2,
                backgroundColor: '#003A5D',
                '&:hover': {
                  backgroundColor: '#002A40',
                }
              }}
            >
              Create New SOP
            </Button>
          </Box>
        ) : (
          <List>
            {sops.map((sop) => (
              <React.Fragment key={sop.id}>
                <ListItem 
                  sx={{ 
                    py: 2,
                    '&:hover': {
                      backgroundColor: 'rgba(0, 0, 0, 0.04)',
                    }
                  }}
                >
                  <ListItemIcon>
                    <AssignmentIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText 
                    primary={
                      <Typography variant="h6" sx={{ fontSize: '1.1rem' }}>
                        {sop.title}
                      </Typography>
                    } 
                    secondary={
                      <>
                        <Typography variant="body2" color="text.secondary">
                          {sop.description || 'No description provided'}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          Created: {sop.createdAt?.toDate().toLocaleDateString() || 'N/A'}
                        </Typography>
                      </>
                    } 
                  />
                  <ListItemSecondaryAction>
                    <IconButton 
                      edge="end" 
                      aria-label="edit"
                      onClick={() => navigate(`/sops/${sop.id}`)}
                      sx={{ mr: 1 }}
                    >
                      <EditIcon />
                    </IconButton>
                    <IconButton 
                      edge="end" 
                      aria-label="delete"
                      onClick={() => handleDeleteSOP(sop.id)}
                    >
                      <DeleteIcon />
                    </IconButton>
                  </ListItemSecondaryAction>
                </ListItem>
                <Divider />
              </React.Fragment>
            ))}
          </List>
        )}
      </Paper>
      
      {/* Create SOP Dialog */}
      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ color: '#003A5D', fontWeight: 'bold' }}>
          Create New SOP
        </DialogTitle>
        <DialogContent>
          {error && (
            <Alert severity="error" sx={{ mb: 2 }}>
              {error}
            </Alert>
          )}
          <TextField
            autoFocus
            margin="dense"
            id="title"
            label="SOP Title"
            type="text"
            fullWidth
            variant="outlined"
            value={sopTitle}
            onChange={(e) => setSopTitle(e.target.value)}
            sx={{ mb: 2 }}
          />
          <TextField
            margin="dense"
            id="description"
            label="Description"
            type="text"
            fullWidth
            variant="outlined"
            multiline
            rows={4}
            value={sopDescription}
            onChange={(e) => setSopDescription(e.target.value)}
          />
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button 
            onClick={handleCreateSOP} 
            variant="contained"
            disabled={dialogLoading}
            sx={{ 
              backgroundColor: '#003A5D',
              '&:hover': {
                backgroundColor: '#002A40',
              }
            }}
          >
            {dialogLoading ? <CircularProgress size={24} /> : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default SOPManagement;
